<div class="notice notice-error is-dismissible">
    <p><?php _e( 'Repeatable content mapping requires the installation of Advanced Custom Fields Pro WordPress Plugin. To enable this functionality, please install and refresh the page.', 'content-workflow' ); ?></p>
</div>
