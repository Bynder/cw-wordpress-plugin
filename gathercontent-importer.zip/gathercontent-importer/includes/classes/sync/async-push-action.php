<?php
namespace GatherContent\Importer\Sync;

class Async_Push_Action extends Async_Base {
	protected $action = 'cwby_push_items';
}
