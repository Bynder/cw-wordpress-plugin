<?php
namespace GatherContent\Importer\Sync;

class Async_Pull_Action extends Async_Base {
	protected $action = 'cwby_pull_items';
}
